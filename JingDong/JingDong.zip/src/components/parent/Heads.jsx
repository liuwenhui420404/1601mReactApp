import React, { Component } from 'react'

export default class Heads extends Component {
    render() {
        return (
            <div className="heads">
                京东
            </div>
        )
    }
}
