export const ADDNUM="add_num"
export const AJAX="ajax"
export const AJAXDATA="ajax_data"
